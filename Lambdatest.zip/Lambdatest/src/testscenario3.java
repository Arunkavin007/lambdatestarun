import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class testscenario3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:/selenium/Selenium/chrome100/chromedriver.exe");
		  WebDriver  driver = new ChromeDriver(); 
		    driver.get("https://www.lambdatest.com/selenium-playground");
		    driver.manage().window().maximize();
		    driver.findElement(By.linkText("Input Form Submit")).click();
		    driver.findElement(By.xpath("//button[@type='submit']")).click();
		   /* Thread.sleep(4000);
		String  s= driver.findElement(By.id("name")).getText() ;
		
		    System.out.println(s);*/
		    
		    driver.findElement(By.id("name")).sendKeys("Arun");
		    driver.findElement(By.id("inputEmail4")).sendKeys("arunkavin007@gmail.com");
		    
		    driver.findElement(By.id("inputPassword4")).sendKeys("Arun");
		    driver.findElement(By.id("company")).sendKeys("nsak");
		    
		    driver.findElement(By.id("websitename")).sendKeys("www.nsak.com");
		    
		    
		    WebElement drp= driver.findElement(By.name("country"));
		    Select sec= new Select(drp);
		    
		    sec.selectByVisibleText("United States");
		    
		    
		    driver.findElement(By.id("inputCity")).sendKeys("chennai");
		    
		    driver.findElement(By.id("inputAddress1")).sendKeys("inputCity");
		    
		    driver.findElement(By.id("inputAddress2")).sendKeys("inputCity");
		    
		    
		    
		    driver.findElement(By.id("inputState")).sendKeys("tamilnadu");
		    
		    
		    driver.findElement(By.id("inputZip")).sendKeys("12345");
		    
		    driver.findElement(By.xpath("//button[@type='submit']")).click(); 
		    
		    
		    
		    String message=  driver.findElement(By.xpath("//*[text()='Thanks for contacting us, we will get back to you shortly.']")).getText();
		    
		    
		   
		   Assert.assertEquals("Thanks for contacting us, we will get back to you shortly.", message);
		    
		    
	}

}
