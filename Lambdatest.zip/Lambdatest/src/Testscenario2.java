import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class Testscenario2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:/selenium/Selenium/chrome100/chromedriver.exe");
		  WebDriver  driver = new ChromeDriver(); 
		    driver.get("https://www.lambdatest.com/selenium-playground");
		    driver.manage().window().maximize();
		    driver.findElement(By.linkText("Drag & Drop Sliders")).click();
		    WebElement slider = driver.findElement(By.xpath("/html/body/div[1]/div[1]/section[3]/div/div/div[2]/div[2]/div[1]/div/input"));
		    int width=slider.getSize().getWidth();
		    Actions move = new Actions(driver);
		    org.openqa.selenium.interactions.Action action  = move.dragAndDropBy(slider, ((width*43)/100), 0).build();
		    action.perform();
		    
		
		
		    
	}

}
