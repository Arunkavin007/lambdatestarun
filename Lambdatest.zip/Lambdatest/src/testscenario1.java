import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.openqa.selenium.Alert;

public class testscenario1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","D:/selenium/Selenium/chrome100/chromedriver.exe");
		  WebDriver  driver = new ChromeDriver(); 
		    driver.get("https://www.lambdatest.com/selenium-playground");
		    driver.manage().window().maximize();
		    driver.findElement(By.partialLinkText("Simple Form Demo")).click();
		   String url= driver.getCurrentUrl();
		if(url.contains("simple-form-demo")) {
			Assert.assertTrue(true);
		}
		
		String Greetings = "Welcome to LambdaTest";
		
		driver.findElement(By.id("user-message")).sendKeys(Greetings);
		
		driver.findElement(By.id("showInput")).click();
		
	String message=	driver.findElement(By.id("message")).getText();
		
	
			Assert.assertEquals(Greetings,message);
		
		
		
		
		
		
		
		    
		    
	  
	}

}
